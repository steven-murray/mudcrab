sample file 00 Core/Docs/Sample Readme.txt
