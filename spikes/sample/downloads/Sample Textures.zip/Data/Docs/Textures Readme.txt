sample file Data/Docs/Textures Readme.txt
